const express = require('express')
const path = require('path')

// 创建 express 应用
const app = express()

// 监听 / 路径的 get 请求
app.get('/', function(req, res) {
  res.sendFile(__dirname+"/"+"public"+"/"+"index.html")
})

// 使 express 监听 5000 端口号发起的 http 请求
const server = app.listen(5000, function() {
	console.log("服务器已启动，监听5000端口");
})

app.use(express.static(path.join(__dirname,"public")))